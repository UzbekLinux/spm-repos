#!/bin/sh
set -e

echo "Automatic removal of linux is not possible now :)"
