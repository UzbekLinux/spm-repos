#!/bin/sh
set -e

CONFIGURE_PREFIX=""
if [ -n "$UZPM_DEST_DIR" ]; then
    mkdir -p "$UZPM_DEST_DIR"
    CONFIGURE_PREFIX="--prefix=$UZPM_DEST_DIR"
fi

git clone --recurse-submodules --shallow-submodules --depth 1 https://github.com/coreutils/coreutils.git
cd coreutils

if [ ! -f configure ]; then
    ./bootstrap
fi

./configure $CONFIGURE_PREFIX

make $MAKE_FLAGS

make install
