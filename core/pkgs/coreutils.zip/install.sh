#!/bin/sh
set -e

echo "This is package from Arch Linux Repository."

DEST="${UZPM_DEST_DIR:-/}"
PKG="coreutils"
URL="https://ftp5.gwdg.de/pub/linux/archlinux/core/os/x86_64/coreutils-9.10-1-x86_64.pkg.tar.zst"
curl -LO "$URL"

mkdir -p "$DEST"

tar -xvf $PKG-*.pkg.tar.zst -C "$DEST" --exclude='.*' | tee "$DEST/var/lib/uzpm/$PKG.tree" >/dev/null
