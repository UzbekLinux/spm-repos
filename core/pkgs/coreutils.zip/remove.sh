#!/bin/sh
set -e

echo "Automatic removal of coreutils is not possible :)"
