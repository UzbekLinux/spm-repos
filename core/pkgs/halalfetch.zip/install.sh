#!/bin/sh
set -e

curl -L -o halalfetch https://raw.githubusercontent.com/UzbekLinux/halalfetch/main/halalfetch

if [ ! -s halalfetch ]; then
    echo "Downloaded file is empty! Aborting."
    exit 1
fi

sudo mkdir -p "$UZPM_DEST_DIR/usr/bin"
sudo cp halalfetch "$UZPM_DEST_DIR/usr/bin/halalfetch"
sudo chmod +x "$UZPM_DEST_DIR/usr/bin/halalfetch"
