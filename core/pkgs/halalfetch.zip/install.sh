#!/bin/sh
set -e

echo "$PWD"
echo "$MAKE_FLAGS"
echo "$DEST_DIR"
echo "Привет, как дела"

curl -L -o halalfetch https://raw.githubusercontent.com/UzbekLinux/halalfetch/main/halalfetch

if [ ! -s halalfetch ]; then
    echo "Downloaded file is empty! Aborting."
    exit 1
fi

sudo cp halalfetch "$DEST_DIR/usr/bin/halalfetch"
sudo chmod +x "$DEST_DIR/usr/bin/halalfetch"
