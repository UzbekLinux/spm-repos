#!/bin/sh

sudo cp sources/halalfetch /usr/bin/halalfetch || { echo "ошибка: не удалось скопировать!"; exit 1; }
sudo chmod +x /usr/bin/halalfetch || { echo "ошибка: не удалось выдать права!"; exit 1; }
