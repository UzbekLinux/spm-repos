#!/bin/sh

if [ "$(id -u)" -ne 0 ]; then
    echo "ошибка: запусти установку от прав суперпользователя!"
    exit 1
fi

cp sources/halalfetch /usr/bin/halalfetch || { echo "ошибка: не удалось скопировать!"; exit 1; }
chmod +x /usr/bin/halalfetch || { echo "ошибка: не удалось выдать права!"; exit 1; }
