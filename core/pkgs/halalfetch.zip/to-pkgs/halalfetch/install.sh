#!/bin/sh

set -e

curl -O https://github.com/UzbekLinux/halalfetch/raw/refs/heads/main/halalfetch

cp halalfetch /usr/bin/halalfetch
chmod +x /usr/bin/halalfetch
