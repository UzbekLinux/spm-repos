#!/bin/sh

set -e

rm /usr/bin/halalfetch
