#!/bin/sh

export

echo 'привет как дела'
