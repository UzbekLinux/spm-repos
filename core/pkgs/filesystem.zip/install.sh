#!/bin/sh
set -e

DEST="${UZPM_DEST_DIR:-/}"

mkdir -p "$DEST"

mkdir -p /bin
mkdir -p /lib
mkdir -p /lib64
mkdir -p /sbin
mkdir -p /etc
mkdir -p /var
mkdir -p /usr

cat > /etc/shells << "EOF"
# Begin /etc/shells

/bin/sh
/bin/ash

# End /etc/shells
EOF

cat > /etc/resolv.conf << "EOF"
# Begin /etc/resolv.conf

nameserver 1.1.1.1
nameserver 8.8.8.8

# End /etc/resolv.conf
EOF

