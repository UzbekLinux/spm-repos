#!/bin/sh
set -e

echo "This package is not intended for removal :)"
