#!/bin/sh
set -e

echo "This is package from Arch Linux Repository."

DEST="${UZPM_DEST_DIR:-/}"

curl -LO https://ftp5.gwdg.de/pub/linux/archlinux/core/os/x86_64/acl-2.3.2-1-x86_64.pkg.tar.zst

mkdir -p "$DEST"

tar -xvf acl-*.pkg.tar.zst .MTREE
install -Dm644 .MTREE "$DEST/var/lib/uzpm/acl.mtree"

tar -xvf acl-*.pkg.tar.zst -C "$DEST" --exclude='.*'
