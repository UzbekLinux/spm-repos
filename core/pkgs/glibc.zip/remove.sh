#!/bin/sh
set -e

DEST="${UZPM_DEST_DIR:-/}"
PKG_NAME="glibc"
TREE_FILE="$DEST/var/lib/uzpm/$PKG_NAME.tree"
PKG_DIR="$DEST/var/lib/uzpm/$PKG_NAME"

if [ -f "$TREE_FILE" ]; then
    echo "Removing files listed in $TREE_FILE..."
    while IFS= read -r file; do
        TARGET="$DEST/$file"
        if [ -f "$TARGET" ] || [ -L "$TARGET" ]; then
            rm -f "$TARGET"
        fi
    done < "$TREE_FILE"
    tac "$TREE_FILE" | while IFS= read -r file; do
        DIR="$DEST/$file"
        [ -d "$DIR" ] && rmdir --ignore-fail-on-non-empty "$DIR" 2>/dev/null || true
    done
    rm -f "$TREE_FILE"
fi

[ -d "$PKG_DIR" ] && rm -rf "$PKG_DIR"
